import { useEffect, useRef, useState } from 'react'
import { MapPin, Phone, Clock, Star, Instagram, ChevronDown, Utensils, Coffee, Cake, Croissant } from 'lucide-react'

function App() {
  const [isVisible, setIsVisible] = useState<Record<string, boolean>>({})
  const sectionsRef = useRef<Record<string, HTMLDivElement | null>>({})

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsVisible((prev) => ({ ...prev, [entry.target.id]: true }))
          }
        })
      },
      { threshold: 0.1 }
    )

    Object.values(sectionsRef.current).forEach((el) => {
      if (el) observer.observe(el)
    })

    return () => observer.disconnect()
  }, [])

  const setRef = (id: string) => (el: HTMLDivElement | null) => {
    sectionsRef.current[id] = el
  }

  const menuItems = [
    {
      category: 'كرواسان',
      icon: <Croissant className="w-5 h-5" />,
      items: [
        { name: 'كرواسان باللوز', price: 'SAR 18' },
        { name: 'كرواسان بالشوكولاتة', price: 'SAR 16' },
        { name: 'كرواسان بأربع جبن', price: 'SAR 22' },
        { name: 'كرواسان بالزعتر والديك الرومي', price: 'SAR 24' },
      ],
    },
    {
      category: 'حلويات',
      icon: <Cake className="w-5 h-5" />,
      items: [
        { name: 'تشيز كيك باسك', price: 'SAR 28' },
        { name: 'كيك المانجو', price: 'SAR 26' },
        { name: 'تارت الفراولة والفانيليا', price: 'SAR 24' },
        { name: 'تيراميسو ياباني', price: 'SAR 22' },
      ],
    },
    {
      category: 'مخبوزات',
      icon: <Utensils className="w-5 h-5" />,
      items: [
        { name: 'مويلو شوكولاتة داكنة', price: 'SAR 20' },
        { name: 'كعك البندق والفستق', price: 'SAR 18' },
        { name: 'يuzu & بذور السمسم', price: 'SAR 22' },
        { name: 'ديليس فستق & فواكه حمراء', price: 'SAR 24' },
      ],
    },
    {
      category: 'قهوة',
      icon: <Coffee className="w-5 h-5" />,
      items: [
        { name: 'اسبريسو', price: 'SAR 12' },
        { name: 'كابتشينو', price: 'SAR 15' },
        { name: 'قهوة مثلجة', price: 'SAR 16' },
        { name: 'لاتيه', price: 'SAR 15' },
      ],
    },
  ]

  return (
    <div className="min-h-screen bg-[#0a0908] text-[#f5f0e8] overflow-x-hidden" dir="rtl">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass-effect border-b border-[#c9a962]/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="text-xl font-bold tracking-wider text-[#c9a962]" style={{ fontFamily: 'Cormorant Garamond, serif' }}>
              TEXTURED
            </div>
            <div className="hidden md:flex items-center gap-8">
              <a href="#about" className="text-sm text-[#f5f0e8]/80 hover:text-[#c9a962] transition-colors duration-300">عنّا</a>
              <a href="#menu" className="text-sm text-[#f5f0e8]/80 hover:text-[#c9a962] transition-colors duration-300">القائمة</a>
              <a href="#gallery" className="text-sm text-[#f5f0e8]/80 hover:text-[#c9a962] transition-colors duration-300">معرض الصور</a>
              <a href="#location" className="text-sm text-[#f5f0e8]/80 hover:text-[#c9a962] transition-colors duration-300">الموقع</a>
              <a href="#contact" className="text-sm text-[#f5f0e8]/80 hover:text-[#c9a962] transition-colors duration-300">تواصل معنا</a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section
        ref={setRef('hero')}
        id="hero"
        className="relative min-h-screen flex items-center justify-center overflow-hidden"
      >
        <div className="absolute inset-0">
          <img
            src="/images/3_Best_bakeries_in_Jeddah_to_start.png"
            alt="TEXTURED bakehouse"
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#0a0908]/70 via-[#0a0908]/50 to-[#0a0908]" />
        </div>

        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <div className={`transition-all duration-1000 ${isVisible.hero ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <p className="text-[#c9a962] text-sm tracking-[0.3em] uppercase mb-4" style={{ fontFamily: 'Inter, sans-serif' }}>
              جدة · الحمراء
            </p>
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-light text-[#f5f0e8] mb-6 leading-tight" style={{ fontFamily: 'Cormorant Garamond, serif' }}>
              TEXTURED
              <span className="block text-3xl md:text-4xl lg:text-5xl font-light text-[#c9a962] mt-2" style={{ fontFamily: 'Cormorant Garamond, serif' }}>
                bakehouse
              </span>
            </h1>
            <p className="text-[#f5f0e8]/70 text-base md:text-lg max-w-xl mx-auto mb-8 leading-relaxed">
              فنّ المخبوزات handmade من الكرواسان الهش إلى الكيك الفاخر.
              <br className="hidden md:block" />
              تجربة تستحق كل قضمة في قلب جدة.
            </p>
            <div className="flex items-center justify-center gap-4 flex-wrap">
              <a
                href="#menu"
                className="bg-[#c9a962] text-[#0a0908] px-8 py-3 text-sm font-medium tracking-wide hover:bg-[#d4b978] transition-all duration-300"
              >
                استكشف القائمة
              </a>
              <a
                href="#location"
                className="border border-[#c9a962]/50 text-[#c9a962] px-8 py-3 text-sm font-medium tracking-wide hover:bg-[#c9a962]/10 transition-all duration-300"
              >
                احجز زيارتك
              </a>
            </div>
          </div>

          <div className={`absolute bottom-10 left-1/2 -translate-x-1/2 transition-all duration-1000 delay-500 ${isVisible.hero ? 'opacity-100' : 'opacity-0'}`}>
            <ChevronDown className="w-6 h-6 text-[#c9a962]/60 animate-bounce" />
          </div>
        </div>
      </section>

      {/* Features Bar */}
      <section className="py-12 border-y border-[#c9a962]/10 bg-[#0d0b09]">
        <div className="max-w-6xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { icon: <Star className="w-5 h-5" />, label: 'تقييم 4.6', sub: '962 تقييم' },
            { icon: <Clock className="w-5 h-5" />, label: '7:00 ص - 11:00 م', sub: 'يومياً' },
            { icon: <MapPin className="w-5 h-5" />, label: 'حي الحمراء', sub: 'جدة' },
            { icon: <Phone className="w-5 h-5" />, label: '057 947 4828', sub: 'اتصل بنا' },
          ].map((item, i) => (
            <div key={i} className="flex flex-col items-center text-center gap-2">
              <div className="text-[#c9a962]">{item.icon}</div>
              <span className="text-[#f5f0e8] text-sm font-medium">{item.label}</span>
              <span className="text-[#f5f0e8]/50 text-xs">{item.sub}</span>
            </div>
          ))}
        </div>
      </section>

      {/* About Section */}
      <section
        ref={setRef('about')}
        id="about"
        className="py-24 md:py-32"
      >
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div className={`transition-all duration-1000 ${isVisible.about ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
              <div className="relative">
                <img
                  src="/images/1_Textured_Bakehouse_in_Jeddah_Restaurant.png"
                  alt="كرواسان TEXTURED"
                  className="w-full aspect-[4/3] object-cover"
                />
                <div className="absolute -bottom-6 -left-6 w-32 h-32 border border-[#c9a962]/30" />
                <div className="absolute -top-6 -right-6 w-32 h-32 border border-[#c9a962]/30" />
              </div>
            </div>
            <div className={`transition-all duration-1000 delay-200 ${isVisible.about ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
              <p className="text-[#c9a962] text-sm tracking-[0.2em] uppercase mb-4" style={{ fontFamily: 'Inter, sans-serif' }}>
                قصتنا
              </p>
              <h2 className="text-4xl md:text-5xl font-light text-[#f5f0e8] mb-6" style={{ fontFamily: 'Cormorant Garamond, serif' }}>
                فنّ المخبوزات بأسلوب عصري
              </h2>
              <p className="text-[#f5f0e8]/70 leading-relaxed mb-6">
                في قلب حي الحمراء بجدة، يقع TEXTURED bakehouse، المخبز الذي أعاد تعريف تجربة المخبوزات الفاخرة.
                من الكرواسان الهش بطبقاته الذهبية، إلى الكيك الغني بنكهاته الدقيقة، كل قطعة تُخبز بشغف وإتقان.
              </p>
              <p className="text-[#f5f0e8]/70 leading-relaxed mb-8">
                نؤمن بأن الجمال يكمن في التفاصيل — من المكونات المختارة بعناية، إلى العروض الزجاجية الفاخرة
                التي تضاهي متاجر المجوهرات. تجربة لا تُنسى لمحبي الفطائر والمخبوزات.
              </p>
              <div className="grid grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-light text-[#c9a962]" style={{ fontFamily: 'Cormorant Garamond, serif' }}>4.6</div>
                  <div className="text-xs text-[#f5f0e8]/50 mt-1">تقييم الزوار</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-light text-[#c9a962]" style={{ fontFamily: 'Cormorant Garamond, serif' }}>962+</div>
                  <div className="text-xs text-[#f5f0e8]/50 mt-1">تقييم إيجابي</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-light text-[#c9a962]" style={{ fontFamily: 'Cormorant Garamond, serif' }}>SAR 20</div>
                  <div className="text-xs text-[#f5f0e8]/50 mt-1">يبدأ من</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Menu Section */}
      <section
        ref={setRef('menu')}
        id="menu"
        className="py-24 md:py-32 bg-[#0d0b09]"
      >
        <div className="max-w-6xl mx-auto px-4">
          <div className={`text-center mb-16 transition-all duration-1000 ${isVisible.menu ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <p className="text-[#c9a962] text-sm tracking-[0.2em] uppercase mb-4" style={{ fontFamily: 'Inter, sans-serif' }}>
              قائمتنا
            </p>
            <h2 className="text-4xl md:text-5xl font-light text-[#f5f0e8]" style={{ fontFamily: 'Cormorant Garamond, serif' }}>
              نكهات تروي قصة
            </h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {menuItems.map((category, idx) => (
              <div
                key={idx}
                className={`border border-[#c9a962]/15 p-8 transition-all duration-1000 hover:border-[#c9a962]/40 ${
                  isVisible.menu ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: `${idx * 150}ms` }}
              >
                <div className="flex items-center gap-3 mb-6">
                  <div className="text-[#c9a962]">{category.icon}</div>
                  <h3 className="text-xl text-[#f5f0e8] font-medium" style={{ fontFamily: 'Cormorant Garamond, serif' }}>
                    {category.category}
                  </h3>
                </div>
                <div className="space-y-4">
                  {category.items.map((item, i) => (
                    <div key={i} className="flex items-center justify-between group">
                      <span className="text-[#f5f0e8]/80 text-sm group-hover:text-[#c9a962] transition-colors duration-300">
                        {item.name}
                      </span>
                      <span className="text-[#c9a962] text-sm font-medium">{item.price}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section
        ref={setRef('gallery')}
        id="gallery"
        className="py-24 md:py-32"
      >
        <div className="max-w-6xl mx-auto px-4">
          <div className={`text-center mb-16 transition-all duration-1000 ${isVisible.gallery ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <p className="text-[#c9a962] text-sm tracking-[0.2em] uppercase mb-4" style={{ fontFamily: 'Inter, sans-serif' }}>
              معرض الصور
            </p>
            <h2 className="text-4xl md:text-5xl font-light text-[#f5f0e8]" style={{ fontFamily: 'Cormorant Garamond, serif' }}>
              لمحة من عالمنا
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className={`transition-all duration-1000 ${isVisible.gallery ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
              <div className="group overflow-hidden">
                <img
                  src="/images/1__TEXTURED_bakehouse_.png"
                  alt="واجهة TEXTURED bakehouse"
                  className="w-full aspect-[4/3] object-cover group-hover:scale-105 transition-transform duration-700"
                />
              </div>
              <p className="text-center text-[#f5f0e8]/50 text-xs mt-3">واجهة المخبز</p>
            </div>
            <div className={`transition-all duration-1000 delay-150 ${isVisible.gallery ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
              <div className="group overflow-hidden">
                <img
                  src="/images/1_Textured_Bakehouse_in_Jeddah_Restaurant.png"
                  alt="كرواسان باللوز"
                  className="w-full aspect-[4/3] object-cover group-hover:scale-105 transition-transform duration-700"
                />
              </div>
              <p className="text-center text-[#f5f0e8]/50 text-xs mt-3">كرواسان باللوز</p>
            </div>
            <div className={`transition-all duration-1000 delay-300 ${isVisible.gallery ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
              <div className="group overflow-hidden">
                <img
                  src="/images/2_Textured_Bakehouse_in_Jeddah_Restaurant.png"
                  alt="حلويات متنوعة"
                  className="w-full aspect-[4/3] object-cover group-hover:scale-105 transition-transform duration-700"
                />
              </div>
              <p className="text-center text-[#f5f0e8]/50 text-xs mt-3">تشكيلة الحلويات</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section
        ref={setRef('testimonials')}
        id="testimonials"
        className="py-24 md:py-32 bg-[#0d0b09]"
      >
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className={`transition-all duration-1000 ${isVisible.testimonials ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <Star className="w-8 h-8 text-[#c9a962] mx-auto mb-6" />
            <blockquote className="text-2xl md:text-3xl font-light text-[#f5f0e8] leading-relaxed mb-8" style={{ fontFamily: 'Cormorant Garamond, serif' }}>
              "أحد أفضل المخابز في جدة إن لم يكن الأفضل. الكرواسان هش والكيك غني بالنكهات.
              جو أنيق وفريق ودود. تجربة لا تُنسى في كل زيارة."
            </blockquote>
            <div className="flex items-center justify-center gap-2">
              <div className="w-10 h-10 rounded-full bg-[#c9a962]/20 flex items-center justify-center text-[#c9a962] text-sm font-medium">
                ع
              </div>
              <div className="text-right">
                <p className="text-[#f5f0e8] text-sm">عبدالرحمن</p>
                <p className="text-[#f5f0e8]/50 text-xs">زبون دائم</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Location Section */}
      <section
        ref={setRef('location')}
        id="location"
        className="py-24 md:py-32"
      >
        <div className="max-w-6xl mx-auto px-4">
          <div className={`text-center mb-16 transition-all duration-1000 ${isVisible.location ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <p className="text-[#c9a962] text-sm tracking-[0.2em] uppercase mb-4" style={{ fontFamily: 'Inter, sans-serif' }}>
              موقعنا
            </p>
            <h2 className="text-4xl md:text-5xl font-light text-[#f5f0e8]" style={{ fontFamily: 'Cormorant Garamond, serif' }}>
              زُرنا في الحمراء
            </h2>
          </div>

          <div className={`grid md:grid-cols-2 gap-12 items-center transition-all duration-1000 ${isVisible.location ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 border border-[#c9a962]/30 flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-5 h-5 text-[#c9a962]" />
                </div>
                <div>
                  <h4 className="text-[#f5f0e8] font-medium mb-1">العنوان</h4>
                  <p className="text-[#f5f0e8]/60 text-sm leading-relaxed">
                    حي الحمراء، بجانب مستشفى الولادة<br />
                    جدة 23324، المملكة العربية السعودية
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 border border-[#c9a962]/30 flex items-center justify-center flex-shrink-0">
                  <Clock className="w-5 h-5 text-[#c9a962]" />
                </div>
                <div>
                  <h4 className="text-[#f5f0e8] font-medium mb-1">ساعات العمل</h4>
                  <p className="text-[#f5f0e8]/60 text-sm">
                    السبت - الخميس: 7:00 ص - 11:00 م
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 border border-[#c9a962]/30 flex items-center justify-center flex-shrink-0">
                  <Phone className="w-5 h-5 text-[#c9a962]" />
                </div>
                <div>
                  <h4 className="text-[#f5f0e8] font-medium mb-1">الهاتف</h4>
                  <p className="text-[#f5f0e8]/60 text-sm" dir="ltr">+966 57 947 4828</p>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="aspect-video bg-[#141210] border border-[#c9a962]/15 flex items-center justify-center">
                <div className="text-center p-8">
                  <MapPin className="w-12 h-12 text-[#c9a962] mx-auto mb-4" />
                  <p className="text-[#f5f0e8]/80 text-sm mb-2">جدة، حي الحمراء</p>
                  <a
                    href="https://www.google.com/maps/place/TEXTURED+bakehouse/@21.5390244,39.1760803"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#c9a962] text-sm hover:underline"
                  >
                    فتح في خرائط جوجل →
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact / CTA Section */}
      <section
        ref={setRef('contact')}
        id="contact"
        className="py-24 md:py-32 bg-[#0d0b09]"
      >
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className={`transition-all duration-1000 ${isVisible.contact ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
            <h2 className="text-4xl md:text-5xl font-light text-[#f5f0e8] mb-6" style={{ fontFamily: 'Cormorant Garamond, serif' }}>
              نحن ننتظرك
            </h2>
            <p className="text-[#f5f0e8]/60 mb-10 max-w-lg mx-auto">
              تفضل بزيارتنا لتجربة المخبوزات الفاخرة، أو تابعنا على إنستغرام لآخر العروض والمخبوزات اليومية.
            </p>
            <div className="flex items-center justify-center gap-4 flex-wrap">
              <a
                href="tel:+966579474828"
                className="bg-[#c9a962] text-[#0a0908] px-8 py-3 text-sm font-medium tracking-wide hover:bg-[#d4b978] transition-all duration-300 flex items-center gap-2"
              >
                <Phone className="w-4 h-4" />
                اتصل الآن
              </a>
              <a
                href="https://www.instagram.com/texturedbakehouse/"
                target="_blank"
                rel="noopener noreferrer"
                className="border border-[#c9a962]/50 text-[#c9a962] px-8 py-3 text-sm font-medium tracking-wide hover:bg-[#c9a962]/10 transition-all duration-300 flex items-center gap-2"
              >
                <Instagram className="w-4 h-4" />
                تابعنا
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-[#c9a962]/10">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="text-2xl font-light text-[#c9a962]" style={{ fontFamily: 'Cormorant Garamond, serif' }}>
              TEXTURED <span className="text-[#f5f0e8]/60">bakehouse</span>
            </div>
            <div className="flex items-center gap-6">
              <a href="#about" className="text-sm text-[#f5f0e8]/50 hover:text-[#c9a962] transition-colors">عنّا</a>
              <a href="#menu" className="text-sm text-[#f5f0e8]/50 hover:text-[#c9a962] transition-colors">القائمة</a>
              <a href="#location" className="text-sm text-[#f5f0e8]/50 hover:text-[#c9a962] transition-colors">الموقع</a>
            </div>
            <div className="text-[#f5f0e8]/30 text-xs">
              © 2025 TEXTURED bakehouse. جميع الحقوق محفوظة.
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App
